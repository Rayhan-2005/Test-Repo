package com.example.fitnesstrackerapp;

import com.example.fitnesstrackerapp.utils.DatabaseConnection;
import javafx.scene.control.Button;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class UserRegistration {

}
