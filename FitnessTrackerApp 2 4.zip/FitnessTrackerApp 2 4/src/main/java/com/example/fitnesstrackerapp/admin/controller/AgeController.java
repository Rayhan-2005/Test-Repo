package com.example.fitnesstrackerapp.admin.controller;

public class AgeController {
}
